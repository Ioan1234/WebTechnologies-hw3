# Instructions

# Obiective : Modify the marked place in  the `app.js` file in order to satisfy the tests

# Steps to run the test and submit the assignment
1. Create a new private repository for the current assignment
2. Clone the repository
3. Copy the content of the assignment to the newly created repo directory
4. From the `main` folder, run `npm install`
5. From the `main` folder, run `npm test`
6. Commit and push the changes
7. Share the repo with `andrei_toma_` or `andrei.toma@ie.ase.ro`